/* Networking DHCPv4 client */

/*
 * Copyright (c) 2017 ARM Ltd.
 * Copyright (c) 2016 Intel Corporation.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include "dhcpClient.h"

LOG_MODULE_REGISTER(net_dhcpv4_client, LOG_LEVEL_INF);

sem_t dhcpActive;

static uint8_t ntp_server[4];

static struct net_mgmt_event_callback mgmt_cb;

static struct net_dhcpv4_option_callback dhcp_cb;

static void start_dhcpv4_client(struct net_if *iface, void *user_data)
{
	// ARG_UNUSED(user_data);
	net_hostname_set((const char*)user_data, strlen((const char*)user_data));
	LOG_INF("Start on %s: index=%d", net_if_get_device(iface)->name,
	net_if_get_by_iface(iface));
#ifdef CONFIG_BOARD_RPI_PICO_RP2040_W
		struct wifi_connect_req_params connect_params = {
#ifdef NASER
        // .ssid = "Naser",
        // .ssid_length = strlen("Naser"),
        // .psk = "nasimore",
        // .psk_length = strlen("nasimore"),
        .ssid = "SAFINE-3-2.4G",
        .ssid_length = strlen("SAFINE-3-2.4G"),
        .psk = "EYE7GLQB73",
        .psk_length = strlen("EYE7GLQB73"),
#elif defined(POURYA)
	
#elif defined(BRAM)
        .ssid = "D21CONTROL",
        .ssid_length = strlen("D21CONTROL"),
        .psk = "District21!",
        .psk_length = strlen("District21!"),
#else

#endif 
		.security = WIFI_SECURITY_TYPE_PSK,
    };	
	net_mgmt(NET_REQUEST_WIFI_CONNECT, iface, &connect_params, sizeof(connect_params));

#else
	uint8_t mac0[6];
	mac0[0] = WIZNET_OUI_B0;
	mac0[1] = WIZNET_OUI_B1;
	mac0[2] = WIZNET_OUI_B2;
	memcpy(&mac0[3], &devId[5], 3);

	struct ethernet_api *eth_api;
	struct ethernet_config config;

	    eth_api = (struct ethernet_api *)net_if_get_device(iface)->api;
    if (!eth_api || !eth_api->set_config) {
        LOG_ERR("Ethernet set_config not supported!\n");
        return;
    }
	LOG_INF("befor");
    /* Set the desired configuration */
    memcpy(config.mac_address.addr, mac0, 6);
	LOG_INF("after");
	const struct device *dev = net_if_get_device(iface);
    /* Apply the configuration */
    if (eth_api->set_config(dev, ETHERNET_CONFIG_TYPE_MAC_ADDRESS, &config) < 0) {
        LOG_ERR("Failed to set Ethernet configuration\n");
    } else {
        LOG_ERR("Ethernet configuration updated successfully\n");
    }
	LOG_DBG("before reagin link add");
	struct net_linkaddr *link_addr = net_if_get_link_addr(iface);

    // LOG_INF("MAC Address in at the begingin: %02x:%02x:%02x:%02x:%02x:%02x\n",
    //        link_addr->addr[0], link_addr->addr[1], link_addr->addr[2], link_addr->addr[3], link_addr->addr[4], link_addr->addr[5]);
    // memcpy(link_addr->addr, mac0, 6);
	// link_addr->len = 6;

    LOG_INF("MAC Address in start: %02x:%02x:%02x:%02x:%02x:%02x\n",
           link_addr->addr[0], link_addr->addr[1], link_addr->addr[2], link_addr->addr[3], link_addr->addr[4], link_addr->addr[5]);
#endif
	net_dhcpv4_start(iface);
}

static void handler(struct net_mgmt_event_callback *cb,
		    uint32_t mgmt_event,
		    struct net_if *iface)
{
	int i = 0;

	if (mgmt_event != NET_EVENT_IPV4_ADDR_ADD) {
		return;
	}

	for (i = 0; i < NET_IF_MAX_IPV4_ADDR; i++) {
		char buf[NET_IPV4_ADDR_LEN];

		if (iface->config.ip.ipv4->unicast[i].ipv4.addr_type !=
							NET_ADDR_DHCP) {
			continue;
		}

		LOG_INF("   Address[%d]: %s", net_if_get_by_iface(iface),
			net_addr_ntop(AF_INET,
			    &iface->config.ip.ipv4->unicast[i].ipv4.address.in_addr,
						  buf, sizeof(buf)));
		LOG_INF("    Subnet[%d]: %s", net_if_get_by_iface(iface),
			net_addr_ntop(AF_INET,
				       &iface->config.ip.ipv4->unicast[i].netmask,
				       buf, sizeof(buf)));
		LOG_INF("    Router[%d]: %s", net_if_get_by_iface(iface),
			net_addr_ntop(AF_INET,
						 &iface->config.ip.ipv4->gw,
						 buf, sizeof(buf)));
		LOG_INF("Lease time[%d]: %u seconds", net_if_get_by_iface(iface),
			iface->config.dhcpv4.lease_time);
			// struct in_addr gateway_addr = {192, 168, 9, 1};
			// struct in_addr gateway_addr = {192, 168, 0, 1};
		// 	struct in_addr gateway_addr = {192, 168, 0, 1};
		// net_if_ipv4_set_gw(iface, &gateway_addr);

		const struct net_linkaddr *link_addr = net_if_get_link_addr(iface);
		const uint8_t *mac = link_addr->addr;

		LOG_INF("MAC Address: %02x:%02x:%02x:%02x:%02x:%02x\n",
			mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
			sem_post(&dhcpActive);
	}
}

static void option_handler(struct net_dhcpv4_option_callback *cb,
			   size_t length,
			   enum net_dhcpv4_msg_type msg_type,
			   struct net_if *iface)
{
	char buf[NET_IPV4_ADDR_LEN];

	LOG_INF("DHCP Option %d: %s", cb->option,
		net_addr_ntop(AF_INET, cb->data, buf, sizeof(buf)));
}

int dhcpClient(const char *deviceName)
{
	LOG_INF("Run dhcpv4 client");

	sem_init(&dhcpActive, 0, 0);
	net_mgmt_init_event_callback(&mgmt_cb, handler,
				     NET_EVENT_IPV4_ADDR_ADD);
	net_mgmt_add_event_callback(&mgmt_cb);

	net_dhcpv4_init_option_callback(&dhcp_cb, option_handler,
					DHCP_OPTION_NTP, ntp_server,
					sizeof(ntp_server));
	
	net_dhcpv4_add_option_callback(&dhcp_cb);

	net_if_foreach(start_dhcpv4_client, deviceName);
	sem_wait(&dhcpActive);

    sem_destroy(&dhcpActive);
	return 0;
}
