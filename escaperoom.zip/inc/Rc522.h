#ifndef __RC522__H__
#define __RC522__H__


#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif
#endif