#ifndef __RFID_OUT__H__
#define __RFID_OUT__H__


#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif
#endif